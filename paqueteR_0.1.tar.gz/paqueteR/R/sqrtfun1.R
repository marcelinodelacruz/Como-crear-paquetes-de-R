#' Ra�z cuadrada 1
#'
#' Funci�n para calcular la ra�z cuadrada.
#'
#' @param x Un vector, o array, num�rico o complejo
#'
#' @return Ra�z cuadrada de x
#' @export
#'
#' @examples sqrt(10)
sqrtfun1 <- function(x) sqrt(x)